//1. feladat
function EkezetesBetukSzama(vizsgaltSzoveg) {
    var darab = 0;
    var betuk = ["á", "é", "í", "ó", "ö", "ő", "ú", "ü", "ű"];
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        if (betuk.includes(vizsgaltSzoveg[i].toLowerCase())) {
            darab++;
        }
    }
    return darab;
}
console.log(EkezetesBetukSzama("A kód elkészítése után ne felejtse azt JavaScript kóddá alakítani majd"));
//2.feladat
/*A faktoriális egy matematikai fogalom, és így jelöljük:
n!
(pl. 5! → "öt faktoriális")
A jelentése:
5! = 1 × 2 × 3 × 4 × 5 = 120*/
function ElsoNszamSzorzat(mennyiseg) {
    var szorzat = 1;
    for (var i = 1; i <= mennyiseg; i++) {
        szorzat = szorzat * i;
    }
    return szorzat;
}
//3.feladat:
function ParosakOsszege(vizsgaltTomb) {
    var osszeg = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) {
            osszeg += vizsgaltTomb[i];
        }
    }
    return osszeg;
}
